# CAPHRV

```shell
adb install caphrv.apk
```

```shell
uv run caphrv.py
```

Created for the Civil Air Patrol.
