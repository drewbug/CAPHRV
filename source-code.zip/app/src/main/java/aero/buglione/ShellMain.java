package aero.buglione;

import com.genymobile.scrcpy.FakeContext;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;
import android.os.Looper;
import android.os.Handler;

public class ShellMain implements SensorEventListener {
    private static final int PPG_SENSOR_TYPE = 65572;
    private static final int PPG_CHANNEL = 2;

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == PPG_SENSOR_TYPE && event.values.length >= PPG_CHANNEL + 1) {
            // Output timestamp and channel 2 value in CSV format
            System.out.println(event.timestamp + "," + event.values[PPG_CHANNEL]);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Ignore
    }

    public static void main(String[] args) {
        try {
            // Get SensorManager via FakeContext
            SensorManager sensorManager = (SensorManager) FakeContext.get().getSystemService(Context.SENSOR_SERVICE);
            if (sensorManager == null) {
                System.err.println("Error: Failed to get SensorManager");
                System.exit(1);
            }

            Sensor sensor = sensorManager.getDefaultSensor(PPG_SENSOR_TYPE);
            if (sensor == null) {
                System.err.println("Error: PPG sensor not found (type " + PPG_SENSOR_TYPE + ")");
                System.exit(1);
            }

            System.out.println("Found sensor: " + sensor.getName());

            // Create a looper thread for sensor callbacks
            Thread looperThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    Looper.prepare();

                    Handler handler = new Handler();
                    ShellMain listener = new ShellMain();

                    boolean success = sensorManager.registerListener(listener, sensor, 0, handler);
                    if (!success) {
                        System.err.println("Error: Failed to register sensor listener");
                        System.exit(1);
                    }

                    System.out.println("=== PPG Channel 2 Monitor ===");
                    System.out.println("Listening for sensor events...\n");

                    Looper.loop();
                }
            });
            looperThread.start();
            looperThread.join();

        } catch (InterruptedException e) {
            System.out.println("\nDone.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
