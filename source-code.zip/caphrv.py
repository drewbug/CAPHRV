# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "heartpy",
#     "numpy",
#     "setuptools<80.9",
# ]
# ///

import subprocess
import sys
import numpy as np
from collections import deque
import time
import heartpy as hp

# Configuration
BUFFER_SIZE = 500
ANALYSIS_INTERVAL = 5
MIN_SAMPLES = 100
SAMPLING_RATE = 25.0

# Biocybernetic Loop Configuration
# Mode: 'STRESS_INOCULATION' or 'ADAPTIVE_DIFFICULTY'
TRAINING_MODE = 'STRESS_INOCULATION'

# HRV Thresholds (RMSSD in milliseconds)
# These values are based on typical HRV ranges for cognitive load assessment
HRV_HIGH_THRESHOLD = 50.0  # Above this = complacent/under-stimulated
HRV_LOW_THRESHOLD = 20.0   # Below this = stressed/overloaded
HRV_NORMAL_RANGE = (HRV_LOW_THRESHOLD, HRV_HIGH_THRESHOLD)

# Turbulence triggering parameters
TRIGGER_COOLDOWN = 30.0  # Seconds between turbulence events

# Global state
value_buffer = deque(maxlen=BUFFER_SIZE)
last_analysis_time = 0
last_trigger_time = 0
current_hrv_state = 'NORMAL'  # 'LOW', 'NORMAL', or 'HIGH'
turbulence_process = None  # Track running turbulence subprocess

print("=== CAPHRV - Civil Air Patrol - Heart Rate Variability ===")
print(f"Training Mode: {TRAINING_MODE}")
print(f"HRV Thresholds: Low={HRV_LOW_THRESHOLD}ms, High={HRV_HIGH_THRESHOLD}ms")
print(f"Trigger Cooldown: {TRIGGER_COOLDOWN}s\n")

def stop_turbulence(reason=''):
    """
    Stops any running turbulence event

    Args:
        reason: Description of why turbulence was stopped
    """
    global turbulence_process

    if turbulence_process and turbulence_process.poll() is None:
        print(f"\n{'='*60}")
        print(f"[TURBULENCE STOP] Terminating active turbulence")
        print(f"Reason: {reason}")
        print(f"{'='*60}\n")

        try:
            turbulence_process.terminate()
            turbulence_process.wait(timeout=2)
            print(f"[SUCCESS] Turbulence stopped successfully")
        except subprocess.TimeoutExpired:
            turbulence_process.kill()
            print(f"[WARNING] Turbulence process killed (did not terminate gracefully)")
        except Exception as e:
            print(f"[ERROR] Failed to stop turbulence: {e}")

        turbulence_process = None
        return True
    else:
        print(f"[INFO] No active turbulence to stop")
        return False

def trigger_turbulence_event(intensity='moderate', reason=''):
    """
    Triggers a turbulence event by invoking turbulence-generator.py

    Args:
        intensity: 'mild', 'moderate', or 'severe'
        reason: Description of why turbulence was triggered
    """
    global last_trigger_time, turbulence_process

    current_time = time.time()

    # Check cooldown period
    if current_time - last_trigger_time < TRIGGER_COOLDOWN:
        time_remaining = TRIGGER_COOLDOWN - (current_time - last_trigger_time)
        print(f"[COOLDOWN] Turbulence trigger blocked. {time_remaining:.1f}s remaining.")
        return False

    # Stop any existing turbulence before starting new event
    if turbulence_process and turbulence_process.poll() is None:
        stop_turbulence(reason="Starting new turbulence event")

    # Update trigger time
    last_trigger_time = current_time

    # Map intensity to wind speed
    intensity_params = {
        'mild': 15.0,
        'moderate': 30.0,
        'severe': 45.0
    }

    wind_speed = intensity_params.get(intensity, intensity_params['moderate'])

    print(f"\n{'='*60}")
    print(f"[TURBULENCE TRIGGER] {intensity.upper()} turbulence initiated")
    print(f"Reason: {reason}")
    print(f"Wind Speed: {wind_speed} ft/s")
    print(f"{'='*60}\n")

    try:
        # Invoke turbulence-generator.py as a background subprocess
        turbulence_process = subprocess.Popen(
            [
                sys.executable, 'turbulence-generator.py',
                '--wind-speed', str(wind_speed),
                '--wind-direction', '270.0'  # Default to left crosswind
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        print(f"[SUCCESS] Turbulence generator started (PID: {turbulence_process.pid})")

    except Exception as e:
        print(f"[ERROR] Failed to invoke turbulence generator: {e}")
        turbulence_process = None
        return False

    return True

def assess_hrv_state(rmssd):
    """
    Assess pilot's physiological state based on HRV (RMSSD)

    Returns: 'LOW', 'NORMAL', or 'HIGH'
    """
    if rmssd < HRV_LOW_THRESHOLD:
        return 'LOW'
    elif rmssd > HRV_HIGH_THRESHOLD:
        return 'HIGH'
    else:
        return 'NORMAL'

def apply_biocybernetic_adaptation(hrv_state, rmssd):
    """
    Apply biocybernetic loop logic based on current HRV state and training mode
    """
    global current_hrv_state

    # Check if state has changed
    state_changed = (hrv_state != current_hrv_state)
    current_hrv_state = hrv_state

    if TRAINING_MODE == 'STRESS_INOCULATION':
        # Trigger turbulence when pilot is complacent (high HRV)
        if hrv_state == 'HIGH':
            if state_changed:
                print(f"[ALERT] HRV indicates complacency (RMSSD={rmssd:.1f}ms)")
                trigger_turbulence_event(
                    intensity='moderate',
                    reason=f"Stress inoculation: HRV too high ({rmssd:.1f}ms > {HRV_HIGH_THRESHOLD}ms)"
                )
        elif hrv_state == 'LOW':
            print(f"[INFO] Pilot under cognitive load (RMSSD={rmssd:.1f}ms) - No intervention")

    elif TRAINING_MODE == 'ADAPTIVE_DIFFICULTY':
        # Maintain continuous challenge, reduce only when pilot is focused/stressed
        if hrv_state == 'LOW':
            # Pilot is focused/stressed - reduce or pause challenges
            if state_changed:
                print(f"[ALERT] HRV indicates focus/stress (RMSSD={rmssd:.1f}ms)")
                stop_turbulence(
                    reason=f"Adaptive mode: Pilot engaged/stressed (RMSSD={rmssd:.1f}ms < {HRV_LOW_THRESHOLD}ms)"
                )
        elif hrv_state == 'NORMAL':
            # Pilot in optimal range - maintain baseline challenge
            if state_changed:
                print(f"[INFO] HRV in optimal range (RMSSD={rmssd:.1f}ms)")
                trigger_turbulence_event(
                    intensity='mild',
                    reason=f"Adaptive difficulty: Maintaining baseline challenge (RMSSD={rmssd:.1f}ms)"
                )
        elif hrv_state == 'HIGH':
            # Pilot complacent - increase challenge to maintain engagement
            if state_changed:
                print(f"[ALERT] HRV indicates complacency (RMSSD={rmssd:.1f}ms)")
                trigger_turbulence_event(
                    intensity='moderate',
                    reason=f"Adaptive difficulty: Increasing challenge to re-engage (RMSSD={rmssd:.1f}ms)"
                )

def analyze_ppg_signal():
    """Analyze PPG signal using HeartPy"""
    global last_analysis_time

    if len(value_buffer) < MIN_SAMPLES:
        return

    signal_data = np.array(list(value_buffer))

    try:
        # Normalize and scale
        signal_data = hp.scale_data(signal_data) * 100

        # Process with HeartPy
        working_data, measures = hp.process(
            signal_data,
            sample_rate=SAMPLING_RATE,
            bpmmin=40,
            bpmmax=180,
            report_time=False
        )

        # Display results
        print("\n" + "="*60)
        print(f"BPM: {measures['bpm']:.1f} | IBI: {measures['ibi']:.1f} ms")
        print(f"SDNN: {measures['sdnn']:.1f} ms | RMSSD: {measures['rmssd']:.1f} ms")
        print(f"pNN50: {measures.get('pnn50', 0):.1f}% | pNN20: {measures.get('pnn20', 0):.1f}%")
        print(f"SD1: {measures.get('sd1', 0):.1f} | SD2: {measures.get('sd2', 0):.1f} | SD1/SD2: {measures.get('sd1/sd2', 0):.3f}")

        if 'lf' in measures and 'hf' in measures:
            print(f"LF: {measures['lf']:.1f} | HF: {measures['hf']:.1f} | LF/HF: {measures['lf/hf']:.3f}")

        print(f"Peaks: {len(working_data['peaklist'])} | Rejected: {len(working_data['removed_beats'])}")

        # Assess HRV state and apply biocybernetic adaptation
        rmssd = measures['rmssd']
        hrv_state = assess_hrv_state(rmssd)
        print(f"HRV State: {hrv_state} (RMSSD: {rmssd:.1f}ms)")
        print("="*60)

        # Apply biocybernetic loop adaptation
        apply_biocybernetic_adaptation(hrv_state, rmssd)

        last_analysis_time = time.time()

    except Exception as e:
        print(f"Analysis error: {e}")

def process_line(line):
    try:
        parts = line.strip().split(',')
        if len(parts) != 2:
            return

        value = float(parts[1])
        value_buffer.append(value)

        # Run analysis every ANALYSIS_INTERVAL seconds
        current_time = time.time()
        if current_time - last_analysis_time >= ANALYSIS_INTERVAL:
            analyze_ppg_signal()

    except (ValueError, IndexError):
        pass


cmd = ['adb', 'shell', 'content read --uri content://caphrv | sh']

process = subprocess.Popen(
    cmd,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    bufsize=1
)

for line in process.stdout:
    line = line.strip()
    if line and not line.startswith('=') and not line.startswith('Found') and not line.startswith('Testing'):
        process_line(line)

process.wait()

