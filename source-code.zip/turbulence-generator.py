# /// script
# dependencies = ["pysimconnect"]
# ///

import math
import argparse
import sys
import time

try:
    from SimConnect import SimConnect, AircraftRequests
    SIMCONNECT_AVAILABLE = True
except ImportError:
    SIMCONNECT_AVAILABLE = False
    print("[WARNING] pysimconnect not available - running in simulation-only mode")

def calculate_crosswind(wind_direction: float, wind_speed: float) -> float:
    return -wind_speed * math.sin(math.radians(wind_direction))

def calculate_headwind(wind_direction: float, wind_speed: float) -> float:
    return wind_speed * math.cos(math.radians(wind_direction))

def calculate_gust_jolt(peak_jolt_fps: float, gust_gradient_ft: float, aircraft_airspeed_fps: float, time_since_start_sec: float) -> float:
    """
    Calculates the instantaneous jolt velocity using the "1-cosine" gust model.
    Formula: V(t) = (U_ds / 2) * (1 - cos( (2 * pi * Va * t) / H ))
    """
    # Prevent division by zero and handle non-moving aircraft
    if aircraft_airspeed_fps <= 0:
        return 0.0

    # Calculate the total duration of the gust event
    gust_duration_sec = gust_gradient_ft / aircraft_airspeed_fps

    # If time is outside the gust's duration [0, duration], the jolt is 0.
    # Use a small tolerance (1e-9) on the upper bound for float precision.
    if not (0.0 <= time_since_start_sec <= (gust_duration_sec + 1e-9)):
        return 0.0

    # Apply the "1-cosine" formula directly
    cosine_argument = (2 * math.pi * aircraft_airspeed_fps * time_since_start_sec) / gust_gradient_ft
    jolt_value = (peak_jolt_fps / 2.0) * (1.0 - math.cos(cosine_argument))

    return jolt_value

def run_simulation_example():
    """Runs a simulation of a gust event and prints the results."""
    
    # --- 1. Define the Scenario ---
    gust_direction = 270.0    # Gust COMING FROM 270 deg relative (Port/Left)
    wind_speed = 30.0          # Gust intensity is 30 ft/s
    aircraft_airspeed = 200.0  # Aircraft is flying at 200 ft/s
    gust_gradient = 100.0      # A "sharp" 100-foot gust

    print(f"--- Simulating Gust Event ---")
    print(f"  Relative Gust From: {gust_direction} deg (0=Head, 90=Right, 270=Left)")
    print(f"  Gust Intensity: {wind_speed} ft/s")
    print(f"  Aircraft Airspeed: {aircraft_airspeed} ft/s")
    print(f"  Gust Gradient: {gust_gradient} ft\n")

    # --- 2. Calculate Peak Jolt Values ---
    peak_jolt_longitudinal = calculate_headwind(gust_direction, wind_speed)
    peak_jolt_lateral = calculate_crosswind(gust_direction, wind_speed)

    print(f"Calculated Peak Jolts:")
    print(f"  Peak Longitudinal (Headwind): {peak_jolt_longitudinal:6.2f} ft/s")
    print(f"  Peak Lateral (Crosswind):     {peak_jolt_lateral:6.2f} ft/s")

    # --- 3. Calculate Gust Duration ---
    total_duration = gust_gradient / aircraft_airspeed
    print(f"  Total Gust Duration: {total_duration:.2f} seconds")
    print("-" * 42)
    print(" Time (s) | Jolt (Longitudinal) | Jolt (Lateral) ")
    print("-" * 42)

    # --- 4. Run the Simulation Loop ---
    time_step = 0.05  # Simulate a 20 FPS update rate
    current_time = 0.0

    # We loop for a bit *after* the gust to show it returns to 0
    while current_time <= total_duration + (2 * time_step):
        
        # Get the instantaneous jolt for the Z-axis (Longitudinal)
        current_jolt_long = calculate_gust_jolt(peak_jolt_longitudinal, 
                                                gust_gradient, 
                                                aircraft_airspeed, 
                                                current_time)
        
        # Get the instantaneous jolt for the X-axis (Lateral)
        current_jolt_lat = calculate_gust_jolt(peak_jolt_lateral, 
                                               gust_gradient, 
                                               aircraft_airspeed, 
                                               current_time)
        
        # In your sim, you would now set the variables:
        # SetData(SimVars.VELOCITY_BODY_Z, current_jolt_long)
        # SetData(SimVars.VELOCITY_BODY_X, current_jolt_lat)
        
        print(f" {current_time:6.2f} | {current_jolt_long:17.2f} | {current_jolt_lat:12.2f}")
        
        current_time += time_step

# Standard Python entry point
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Generate turbulence events for flight simulator')
    parser.add_argument('--wind-speed', type=float, default=30.0,
                        help='Wind speed in ft/s (default: 30.0)')
    parser.add_argument('--wind-direction', type=float, default=270.0,
                        help='Wind direction in degrees relative to aircraft (default: 270.0)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Run without connecting to MSFS (simulation only)')

    args = parser.parse_args()

    # Hardcoded parameters
    gust_gradient = 100.0  # Standard gust gradient
    aircraft_airspeed = 200.0  # Default/fallback airspeed

    # Initialize SimConnect
    sm = None
    aq = None
    simconnect_active = False

    if SIMCONNECT_AVAILABLE and not args.dry_run:
        try:
            print("[SimConnect] Attempting to connect to MSFS...")
            sm = SimConnect()
            aq = AircraftRequests(sm, _time=2000)

            # Test connection by reading airspeed
            airspeed_true = aq.get("AIRSPEED_TRUE")
            aircraft_airspeed = airspeed_true * 1.68781  # Convert knots to ft/s

            if aircraft_airspeed < 10.0:
                print(f"[SimConnect] WARNING: Aircraft airspeed very low ({aircraft_airspeed:.1f} ft/s)")
                print(f"[SimConnect] Using default airspeed of 200.0 ft/s")
                aircraft_airspeed = 200.0
            else:
                print(f"[SimConnect] Connected successfully!")
                print(f"[SimConnect] Reading live airspeed: {aircraft_airspeed:.1f} ft/s")
                simconnect_active = True

        except Exception as e:
            print(f"[SimConnect] Connection failed: {e}")
            print(f"[SimConnect] Running in simulation-only mode")
            aircraft_airspeed = 200.0
    else:
        if args.dry_run:
            print("[SimConnect] Dry-run mode enabled - simulation only")
        aircraft_airspeed = 200.0

    # Run simulation with provided parameters
    print(f"\n--- Turbulence Event Triggered by CAPHRV ---")
    print(f"  Wind Speed: {args.wind_speed} ft/s")
    print(f"  Wind Direction: {args.wind_direction} deg")
    print(f"  Gust Gradient: {gust_gradient} ft")
    print(f"  Aircraft Airspeed: {aircraft_airspeed:.1f} ft/s {'(LIVE)' if simconnect_active else '(DEFAULT)'}")

    # Calculate peak jolts
    peak_jolt_longitudinal = calculate_headwind(args.wind_direction, args.wind_speed)
    peak_jolt_lateral = calculate_crosswind(args.wind_direction, args.wind_speed)

    print(f"\nPeak Jolts:")
    print(f"  Longitudinal: {peak_jolt_longitudinal:6.2f} ft/s")
    print(f"  Lateral: {peak_jolt_lateral:6.2f} ft/s")

    # Calculate gust duration
    total_duration = gust_gradient / aircraft_airspeed
    print(f"  Gust Duration: {total_duration:.2f} seconds")

    if simconnect_active:
        print(f"\n[ACTIVE] Applying turbulence forces to MSFS via SimConnect")
    else:
        print(f"\n[SIMULATION] Displaying turbulence profile (not applied to sim)")

    print("-" * 50)
    print(" Time (s) | Jolt (Long) | Jolt (Lat) | Applied")
    print("-" * 50)

    # Turbulence application loop
    time_step = 0.05  # 20 Hz update rate
    current_time = 0.0
    steps_shown = 0

    try:
        while current_time <= total_duration:
            # Calculate current jolt values
            current_jolt_long = calculate_gust_jolt(peak_jolt_longitudinal,
                                                    gust_gradient,
                                                    aircraft_airspeed,
                                                    current_time)

            current_jolt_lat = calculate_gust_jolt(peak_jolt_lateral,
                                                   gust_gradient,
                                                   aircraft_airspeed,
                                                   current_time)

            # Apply forces to simulator if connected
            applied_status = "No"
            if simconnect_active and aq:
                try:
                    # Set body velocities in MSFS
                    # VELOCITY_BODY_Z = longitudinal (forward/back)
                    # VELOCITY_BODY_X = lateral (left/right)
                    aq.set("VELOCITY_BODY_Z", current_jolt_long)
                    aq.set("VELOCITY_BODY_X", current_jolt_lat)
                    applied_status = "Yes"
                except Exception as e:
                    print(f"\n[ERROR] Failed to apply forces: {e}")
                    simconnect_active = False

            # Display output (abbreviated for long durations)
            if steps_shown < 10 or current_time >= total_duration - time_step:
                print(f" {current_time:7.2f} | {current_jolt_long:10.2f} | {current_jolt_lat:9.2f} | {applied_status:7s}")
            elif steps_shown == 10:
                print("   ...    |     ...     |    ...     |   ...")

            steps_shown += 1
            current_time += time_step

            # Sleep to maintain update rate
            if simconnect_active:
                time.sleep(time_step)

        print("-" * 50)
        print("[SUCCESS] Turbulence event completed")

    except KeyboardInterrupt:
        print("\n[INTERRUPT] Turbulence event cancelled by user")
    finally:
        # Cleanup SimConnect connection
        if sm:
            try:
                sm.exit()
                print("[SimConnect] Connection closed")
            except:
                pass
